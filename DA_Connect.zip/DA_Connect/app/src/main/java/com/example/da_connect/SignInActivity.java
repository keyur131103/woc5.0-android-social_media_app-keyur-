package com.example.da_connect;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.material.button.MaterialButton;

public class SignInActivity extends AppCompatActivity {


    MaterialButton signup;

    GoogleSignInClient mGoogleSignInClient;
    private static Bundle RC_SIGN_IN;



   // ImageView fbButton;

   // CallbackManager callbackmanager;
   // LoginManager loginmanager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);
//facebook
       /* FacebookSdk.sdkInitialize(getApplicationContext());
        setContentView(R.layout.activity_signin);

        callbackmanager = CallbackManager.Factory.create();



        LoginManager.getInstance().registerCallback(callbackmanager, new FacebookCallback<LoginResult>() {
                    @Override
                    public void onSuccess(LoginResult loginResult) {
                        startActivity(new Intent(SignInActivity.this, AfterFacebook.class));
                        loginmanager.logInWithReadPermissions(SignInActivity.this, Arrays.asList("email", "public_profile"));
                        finish();
                    }

                    @Override
                    public void onCancel() {
                        // App code
                    }

                    @Override
                    public void onError(@NonNull FacebookException exception) {
                        // App code
                    }
                });

        fbButton = findViewById(R.id.fb_btn);
        fbButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginmanager.logInWithReadPermissions(SignInActivity.this, Arrays.asList("email", "public_profile"));
            }
        });


*/      //Don't have an account?SIGN UP Redirection
        signup = (MaterialButton) findViewById(R.id.signup);

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSignUpActivity();
            }
        });

        TextView email = (TextView) findViewById(R.id.email);
        TextView password = (TextView) findViewById(R.id.password);
        Button signin = (Button) findViewById(R.id.signin);

        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(email.getText().toString().equals("admin") && password.getText().toString().equals("admin")) {
                    Toast.makeText(SignInActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(SignInActivity.this, "Login Failed!", Toast.LENGTH_SHORT).show();
                }

            }
        });
 //google



    }
    public void openSignUpActivity() {

        Intent intent = new Intent(this,SignUpActivity.class);
        startActivity(intent);

    }
}
