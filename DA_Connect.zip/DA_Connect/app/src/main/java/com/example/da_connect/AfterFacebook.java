package com.example.da_connect;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.facebook.AccessToken;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginManager;

import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.json.JSONObject;

import kotlin.jvm.JvmStatic;

public class AfterFacebook extends AppCompatActivity {

    ImageView imageView;
    TextView Name;
    Button logout;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_after_facebook);

        imageView = findViewById(R.id.imageview);
        Name = findViewById(R.id.name);
        logout = findViewById(R.id.logout);

        AccessToken accessToken = AccessToken.getCurrentAccessToken();

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LoginManager.getInstance().logOut();
                startActivity(new Intent(AfterFacebook.this, SignInActivity.class));
                finish();
            }
        });


        GraphRequest request = GraphRequest.newMeRequest(
                accessToken,
                new GraphRequest.GraphJSONObjectCallback() {
                    @Override
                    public void onCompleted(
                            JSONObject object,
                            GraphResponse response) {
                        // Application code
                        String fullname = null;
                        try {
                            fullname = object.getString("Name");
                        } catch (JSONException ex) {
                            ex.printStackTrace();
                        }
                        Name.setText(fullname);
                    }
                });
        Bundle parameters = new Bundle();
        parameters.putString("fields", "id,name,link");
        request.setParameters(parameters);
        request.executeAsync();


    }
}